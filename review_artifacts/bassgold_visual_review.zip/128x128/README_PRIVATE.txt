Run: /media/ra/KINGSTON/drillcore-logging-work/outputs/bassgold_2026-11_t128/runs/pilot_t128_extended_20261123_145424
Split: val
Tiles root: /media/ra/KINGSTON/drillcore-logging-work/outputs/bassgold_2026-11_t128
Correct means agreement with journal, not proof the rock type is geologically correct.
Confidence is the model softmax probability of its predicted class.
These images contain rock-photo tiles and must not be uploaded to public GitHub.
