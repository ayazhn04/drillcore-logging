Run: /media/ra/KINGSTON/drillcore-logging-work/outputs/bassgold_2026-11/runs/diag_weighted_60_mid_20261123_151926
Split: val
Tiles root: /media/ra/KINGSTON/drillcore-logging-work/outputs/bassgold_2026-11
Correct means agreement with journal, not proof the rock type is geologically correct.
Confidence is the model softmax probability of its predicted class.
These images contain rock-photo tiles and must not be uploaded to public GitHub.
